package JKU_MMS.Model;

public interface OnTaskCompleteListener {
    public void taskComplete(Task t, Exception e);
}
