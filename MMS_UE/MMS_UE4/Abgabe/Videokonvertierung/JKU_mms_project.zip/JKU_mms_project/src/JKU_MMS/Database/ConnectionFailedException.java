package JKU_MMS.Database;

public class ConnectionFailedException extends Exception {

    ConnectionFailedException(String msg) {
        super(msg);
    }
}
