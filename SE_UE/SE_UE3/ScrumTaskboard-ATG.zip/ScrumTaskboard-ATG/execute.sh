java -jar ScrumTaskboard.jar ScrumTaskboard-input.txt
